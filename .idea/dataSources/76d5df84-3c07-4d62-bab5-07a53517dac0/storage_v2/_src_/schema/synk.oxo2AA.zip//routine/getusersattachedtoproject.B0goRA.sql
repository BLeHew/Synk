create procedure GetUsersAttachedToProject(IN ProjID int)
  begin
select u.id,u.username from users u, user_proj_assigned upa
where u.id = upa.user_id and upa.proj_id = ProjID;
end;

