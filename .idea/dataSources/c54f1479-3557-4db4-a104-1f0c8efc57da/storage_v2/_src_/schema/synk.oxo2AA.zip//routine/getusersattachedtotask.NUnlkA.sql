create procedure GetUsersAttachedToTask(IN TaskID int)
  begin
select * from users u, user_task_assigned uta
where u.id = uta.user_id and uta.task_id = TaskID;
end;

