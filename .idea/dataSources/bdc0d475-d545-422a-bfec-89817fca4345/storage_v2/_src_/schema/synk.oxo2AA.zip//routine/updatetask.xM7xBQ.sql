create procedure UpdateTask(IN newname varchar(50), IN id int)
  begin
update task set name = newname where task.id = id;
end;

