create procedure InsertProject(IN name varchar(30), IN description text)
  begin
insert into project values(null,name,description);
end;

