create procedure InsertUser(IN username varchar(30), IN email varchar(50), IN pass_hash bigint, IN priv_level int)
  begin
insert into users values(null,username,email,pass_hash,priv_level);
end;

