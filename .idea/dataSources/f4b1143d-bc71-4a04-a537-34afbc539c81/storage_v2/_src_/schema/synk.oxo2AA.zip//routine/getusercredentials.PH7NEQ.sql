create procedure GetUserCredentials(IN user_name varchar(255))
  begin
select username,pass_hash from users where username = user_name;
end;

