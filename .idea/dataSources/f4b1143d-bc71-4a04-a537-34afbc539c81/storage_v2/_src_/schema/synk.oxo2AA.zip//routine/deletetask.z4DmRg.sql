create procedure DeleteTask(IN taskId int)
  begin
delete from tasks where id = taskId;
end;

