create procedure InsertTask(IN name varchar(30), IN proj_id int, IN description text)
  begin 
insert into task values(null,proj_id,name,description);
end;

