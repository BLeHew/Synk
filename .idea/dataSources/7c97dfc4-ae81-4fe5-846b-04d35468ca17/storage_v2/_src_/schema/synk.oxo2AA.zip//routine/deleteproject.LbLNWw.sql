create procedure DeleteProject(IN projId int)
  begin
delete from project where id = projId;
end;

